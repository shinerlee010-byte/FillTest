// src/knot_vector.cpp
#include <nurbs_filler/knot_vector.h>

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace nurbs_filler {

KnotVector::KnotVector(std::vector<Real> values) : values_(std::move(values)) {
    if (values_.size() < 2) {
        throw std::invalid_argument("KnotVector: must have at least 2 entries");
    }
    if (!std::is_sorted(values_.begin(), values_.end())) {
        throw std::invalid_argument("KnotVector: must be non-decreasing");
    }
}

KnotVector KnotVector::UniformClamped(std::size_t count, std::size_t degree) {
    return UniformClamped(count, degree, Real(0), Real(1));
}

KnotVector KnotVector::UniformClamped(std::size_t count, std::size_t degree,
                                      Real t_min, Real t_max) {
    if (count < degree + 1) {
        throw std::invalid_argument(
            "KnotVector::UniformClamped: need count >= degree+1");
    }
    if (degree == 0 && count < 2) {
        throw std::invalid_argument(
            "KnotVector::UniformClamped: degree 0 needs count >= 2");
    }
    if (t_max <= t_min) {
        throw std::invalid_argument("KnotVector::UniformClamped: t_max must > t_min");
    }
    const std::size_t n = count - 1;                          // index of last ctrl pt
    const std::size_t m = n + degree + 1;                     // size of knot vector
    std::vector<Real> u(m);

    // p+1 zeros
    for (std::size_t i = 0; i <= degree; ++i) {
        u[i] = t_min;
    }
    // p+1 ones
    for (std::size_t i = m - degree - 1; i < m; ++i) {
        u[i] = t_max;
    }
    // interior knots uniformly spaced
    const std::size_t num_interior = m - 2 * (degree + 1);
    if (num_interior > 0) {
        const Real span = (t_max - t_min) / static_cast<Real>(num_interior + 1);
        for (std::size_t i = 0; i < num_interior; ++i) {
            u[degree + 1 + i] = t_min + span * static_cast<Real>(i + 1);
        }
    }
    return KnotVector(std::move(u));
}

Real KnotVector::operator[](std::size_t i) const {
    return values_.at(i);
}

Real KnotVector::Front() const noexcept { return values_.front(); }
Real KnotVector::Back() const noexcept { return values_.back(); }

std::size_t KnotVector::MultiplicityOf(Real value) const {
    std::size_t m = 0;
    for (Real u : values_) {
        // Use relative tolerance because knot vectors are computed from
        // arithmetic on small numbers.
        if (std::abs(u - value) <= Tolerance::kLoose) ++m;
    }
    return m;
}

std::size_t KnotVector::FindSpan(std::size_t n, std::size_t p, Real u) const {
    // Algorithm A2.1 from "The NURBS Book".
    if (values_.size() != n + p + 2) {
        throw std::invalid_argument("KnotVector::FindSpan: vector length mismatch");
    }
    if (u >= values_.back()) {
        // Last span is degenerate by convention; clamp.
        return n;
    }
    if (u <= values_.front()) {
        return p;
    }
    // Binary search
    std::size_t lo = p;
    std::size_t hi = n + 1;
    while (hi - lo > 1) {
        const std::size_t mid = (lo + hi) / 2;
        if (u < values_[mid]) hi = mid;
        else                 lo = mid;
    }
    return lo;
}

void KnotVector::Validate(std::size_t expected_num_ctrlpts,
                          std::size_t expected_degree) const {
    if (values_.size() != expected_num_ctrlpts + expected_degree + 1) {
        throw std::invalid_argument(
            "KnotVector::Validate: size mismatch (got " +
            std::to_string(values_.size()) + ", want " +
            std::to_string(expected_num_ctrlpts + expected_degree + 1) + ")");
    }
    for (std::size_t i = 1; i < values_.size(); ++i) {
        if (values_[i] < values_[i - 1] - Tolerance::kEps) {
            throw std::invalid_argument("KnotVector::Validate: not non-decreasing");
        }
    }
    if (expected_degree > 0) {
        // Clamping means front multiplicity == degree+1 and same at back.
        std::size_t fm = 0, bm = 0;
        for (Real u : values_) {
            if (std::abs(u - values_.front()) <= Tolerance::kLoose) ++fm;
            if (std::abs(u - values_.back()) <= Tolerance::kLoose) ++bm;
        }
        if (fm < expected_degree + 1 || bm < expected_degree + 1) {
            throw std::invalid_argument(
                "KnotVector::Validate: not clamped at both ends");
        }
    }
}

std::vector<Real> ChordLengthParameters(const std::vector<Vec3>& points) {
    if (points.size() < 2) {
        throw std::invalid_argument("ChordLengthParameters: need >= 2 points");
    }
    std::vector<Real> t(points.size());
    t[0] = Real(0);
    Real total = Real(0);
    for (std::size_t i = 1; i < points.size(); ++i) {
        const Real d = (points[i] - points[i - 1]).norm();
        if (!(d > Real(0))) {
            throw std::invalid_argument(
                "ChordLengthParameters: duplicate consecutive points");
        }
        total += d;
        t[i] = total;
    }
    const Real inv = Real(1) / total;
    for (auto& ti : t) ti *= inv;
    return t;
}

std::vector<Real> ChordLengthParameters2D(const std::vector<Vec2>& points) {
    if (points.size() < 2) {
        throw std::invalid_argument("ChordLengthParameters2D: need >= 2 points");
    }
    std::vector<Real> t(points.size());
    t[0] = Real(0);
    Real total = Real(0);
    for (std::size_t i = 1; i < points.size(); ++i) {
        const Real d = (points[i] - points[i - 1]).norm();
        if (!(d > Real(0))) {
            throw std::invalid_argument(
                "ChordLengthParameters2D: duplicate consecutive points");
        }
        total += d;
        t[i] = total;
    }
    const Real inv = Real(1) / total;
    for (auto& ti : t) ti *= inv;
    return t;
}

}  // namespace nurbs_filler