// tests/test_fitting.cpp
#include <nurbs_filler/fitting.h>
#include <nurbs_filler/surface.h>

#include <gtest/gtest.h>

#include <cmath>
#include <vector>

using namespace nurbs_filler;

namespace {

// Sample a torus point cloud in (theta, phi) parameter coordinates.
std::vector<DataConstraint> MakeTorusData(std::size_t nu, std::size_t nv,
                                           Real R = 1.5, Real r = 0.5) {
    std::vector<DataConstraint> data;
    for (std::size_t i = 0; i < nu; ++i) {
        const Real u = static_cast<Real>(i) / (nu - 1);
        const Real theta = u * 2.0 * M_PI;
        for (std::size_t j = 0; j < nv; ++j) {
            const Real v = static_cast<Real>(j) / (nv - 1);
            const Real phi = v * 2.0 * M_PI;
            const Vec3 p(
                (R + r * std::cos(phi)) * std::cos(theta),
                (R + r * std::cos(phi)) * std::sin(theta),
                r * std::sin(phi));
            DataConstraint d;
            d.u = u; d.v = v; d.p = p; d.weight = 1.0;
            data.push_back(d);
        }
    }
    return data;
}

}  // namespace

TEST(Fitting, LeastSquaresFitsSmoothData) {
    auto data = MakeTorusData(20, 20);
    FitOptions opts;
    opts.pu = 3; opts.pv = 3;
    opts.n_ctrl_u = 10; opts.n_ctrl_v = 10;
    Surface s = FitSurfaceFromConstraints(data, {}, opts);

    // Sample the surface on the data parameter grid and check the max
    // distance from the analytical torus point.
    Real R = 1.5, r = 0.5;
    Real max_err = 0;
    for (std::size_t i = 0; i < 20; ++i) {
        const Real u = static_cast<Real>(i) / 19.0;
        for (std::size_t j = 0; j < 20; ++j) {
            const Real v = static_cast<Real>(j) / 19.0;
            const Vec3 got = s.PointAt(u, v);
            const Real theta = u * 2.0 * M_PI;
            const Real phi = v * 2.0 * M_PI;
            const Vec3 want(
                (R + r * std::cos(phi)) * std::cos(theta),
                (R + r * std::cos(phi)) * std::sin(theta),
                r * std::sin(phi));
            max_err = std::max(max_err, (got - want).norm());
        }
    }
    // Torus is a transcendental surface; cubic B-spline approx with
    // 10x10 control points on a 20x20 sample should be within ~1e-2.
    EXPECT_LT(max_err, 5e-2) << "max_err=" << max_err;
}

TEST(Fitting, HardConstraintPassesExactly) {
    // Few data points + an exact hard constraint should make the surface
    // pass through the hard point.
    std::vector<DataConstraint> data;
    for (int i = 0; i < 4; ++i) {
        DataConstraint d;
        d.u = static_cast<Real>(i) / 3.0;
        d.v = 0.0;
        d.p = Vec3(d.u, d.u * d.u, 0);
        data.push_back(d);
    }
    std::vector<HardPointConstraint> hard;
    {
        HardPointConstraint h;
        h.u = 0.5; h.v = 0.5;
        h.p = Vec3(0.5, 0.25, 1.0);
        h.lambda = 1e10;
        hard.push_back(h);
    }
    FitOptions opts;
    opts.pu = 3; opts.pv = 3;
    opts.n_ctrl_u = 6; opts.n_ctrl_v = 6;
    Surface s = FitSurfaceFromConstraints(data, hard, opts);

    const Vec3 got = s.PointAt(0.5, 0.5);
    EXPECT_NEAR(got.x(), 0.5, 1e-4);
    EXPECT_NEAR(got.y(), 0.25, 1e-4);
    EXPECT_NEAR(got.z(), 1.0, 1e-4);
}