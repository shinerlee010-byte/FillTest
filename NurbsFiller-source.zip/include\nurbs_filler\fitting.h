// include/nurbs_filler/fitting.h
//
// Constrained NURBS surface fitting.
//
// Goal: given a cloud of 3D data points (each with optional parameter
// coordinates (u, v) or with spatial layout), find a NURBS surface that
//
//   1. (soft) approximately passes through the data points
//   2. (hard) strictly passes through user-specified anchor points
//   3. (hard) has its four edges lie on four user-specified boundary curves
//
// All three constraint families are encoded into a single weighted
// normal-equation system:
//
//   (N^T W N) x = N^T W y     (least-squares for data points)
//
// then augmented by adding the hard-constraint rows multiplied by a large
// factor lambda_hard (a soft-then-hard penalty technique that works well
// when lambda is chosen large enough, e.g. 1e8).
//
// References:
//   Piegl L., Tiller W. "The NURBS Book", 2nd ed., Springer 1997,
//   Chapter 9 ("Surface Fitting").
//   Park H. "An error-bounded non-uniform B-spline surface fitting
//            algorithm using simulated annealing", 2003 (for hard constraints).

#pragma once

#include <nurbs_filler/curve.h>
#include <nurbs_filler/surface.h>
#include <nurbs_filler/types.h>

#include <cstddef>
#include <vector>

namespace nurbs_filler {

// A data point with a parameter location. The "weight" scales the row of
// the normal equations (defaults to 1).
struct DataConstraint {
    Real u = 0;
    Real v = 0;
    Vec3 p = Vec3::Zero();
    Real weight = Real(1);
};

// A hard position constraint: the surface must pass exactly through `p`
// at parameter (u, v). The "lambda" is the penalty weight used when the
// system is augmented (defaults to a large value).
struct HardPointConstraint {
    Real u = 0;
    Real v = 0;
    Vec3 p = Vec3::Zero();
    Real lambda = Real(1e8);
};

// Boundary curve specification. The user provides one Curve for each of
// the four edges. We sample each at `n_samples` parameter values and convert
// each sample into a HardPointConstraint so the surface boundary passes
// exactly through those points.
//
// Curve direction is u; the boundary curve is re-parameterised to the
// surface's u- or v-range, which KnotVector::UniformClamped provides.
struct BoundaryConstraint {
    Curve curve_u;       // parameterised by u, evaluated at u in [0, 1]
    Curve curve_v;       // parameterised by v, evaluated at v in [0, 1]
    std::size_t n_samples = 16;
    Real lambda = Real(1e8);
};

struct FitOptions {
    std::size_t pu = 3;          // degree in u
    std::size_t pv = 3;          // degree in v
    std::size_t n_ctrl_u = 0;    // number of control points in u
    std::size_t n_ctrl_v = 0;    // number of control points in v
    bool normalize = true;       // normalise data columns before solve
    Real ridge = Real(0);        // optional L2 regularisation on control pts
};

// Solve a constrained NURBS surface fitting problem.
//
// Inputs:
//   - data: cloud of 3D points with (u, v) parameter coordinates.
//   - hard_points: anchor points the surface must pass through exactly.
//   - boundary: optional, curves that define the four edges.
//   - options: degree and control point counts; defaults are derived
//              from the input if zero.
//
// Returns a Surface whose Validate() passes.
//
// Throws std::invalid_argument on inconsistent inputs.
Surface FitSurfaceFromConstraints(
    const std::vector<DataConstraint>& data,
    const std::vector<HardPointConstraint>& hard_points,
    const BoundaryConstraint* boundary,
    const FitOptions& options);

// Convenience overload for the common case (no boundary).
inline Surface FitSurfaceFromConstraints(
    const std::vector<DataConstraint>& data,
    const std::vector<HardPointConstraint>& hard_points,
    const FitOptions& options) {
    return FitSurfaceFromConstraints(data, hard_points, nullptr, options);
}

}  // namespace nurbs_filler