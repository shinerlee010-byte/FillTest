// tests/test_basis.cpp
#include <nurbs_filler/basis.h>
#include <nurbs_filler/knot_vector.h>

#include <gtest/gtest.h>

#include <cmath>
#include <vector>

using namespace nurbs_filler;

TEST(Basis, PartitionOfUnity) {
    // For any clamped knot vector, the basis functions at any u should
    // sum to 1.
    auto kv = KnotVector::UniformClamped(6, 3);
    const std::size_t p = 3;
    std::vector<Real> u_vals = {0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0 - 1e-9};
    std::vector<Real> N(6);
    for (Real u : u_vals) {
        AllBasisFunctions(kv, 5, p, u, N.data());
        Real sum = 0;
        for (Real v : N) sum += v;
        EXPECT_NEAR(sum, 1.0, 1e-9);
    }
}

TEST(Basis, ConstantDegree0) {
    auto kv = KnotVector::UniformClamped(5, 0);
    // For p = 0, basis function is 1 iff u is in the i-th knot span.
    const std::size_t p = 0;
    std::vector<Real> N(5);
    AllBasisFunctions(kv, 4, p, Real(0.1), N.data());
    // First knot span [0, 0.25): only N[0] is 1.
    EXPECT_NEAR(N[0], 1.0, Tolerance::kEps);
    EXPECT_NEAR(N[1], 0.0, Tolerance::kEps);
    EXPECT_NEAR(N[2], 0.0, Tolerance::kEps);
    EXPECT_NEAR(N[3], 0.0, Tolerance::kEps);
    EXPECT_NEAR(N[4], 0.0, Tolerance::kEps);
}

TEST(Basis, EndPointValue) {
    // For a clamped cubic B-spline curve, C(0) = P_0 and C(1) = P_n.
    // The basis functions at u=0 give N_0(0) = 1, others 0. Same at u=1.
    auto kv = KnotVector::UniformClamped(6, 3);
    std::vector<Real> N(6);
    AllBasisFunctions(kv, 5, 3, Real(0), N.data());
    EXPECT_NEAR(N[0], 1.0, Tolerance::kEps);
    for (std::size_t i = 1; i < 6; ++i) EXPECT_NEAR(N[i], 0.0, Tolerance::kEps);

    // At u = 1 (the clamped end), N[n] = 1.
    // Because FindSpan clamps to n when u >= U.back(), the local span is
    // n and the local basis function N_local[0..p] = N_{n-p..n}. At u=1
    // these must put the weight onto N_n.
    AllBasisFunctions(kv, 5, 3, Real(1.0 - 1e-12), N.data());
    Real last = N[5];
    EXPECT_NEAR(last, 1.0, 1e-9);
}

TEST(Basis, DerivativeMatchesFiniteDiff) {
    auto kv = KnotVector::UniformClamped(8, 3);
    const std::size_t p = 3;
    const Real h = 1e-6;

    std::vector<Real> N_plus(8), N_minus(8), N_deriv(8);
    for (Real u : {0.1, 0.25, 0.4, 0.55, 0.7, 0.85}) {
        AllBasisFunctions(kv, 7, p, u + h, N_plus.data());
        AllBasisFunctions(kv, 7, p, u - h, N_minus.data());
        BasisFunctionDerivativesAll(kv, 7, p, u, 1, N_deriv.data());
        for (std::size_t i = 0; i < 8; ++i) {
            const Real fd = (N_plus[i] - N_minus[i]) / (2 * h);
            EXPECT_NEAR(N_deriv[i], fd, 1e-3) << "u=" << u << " i=" << i;
        }
    }
}