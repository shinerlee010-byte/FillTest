// include/nurbs_filler/knot_vector.h
//
// A B-spline / NURBS knot vector is a non-decreasing sequence of real values
// of length n + p + 1, where n is the number of control points and p the
// polynomial degree. The first and last knots are conventionally repeated
// (p+1) times to make the spline clamped at both ends.
//
// References: Piegl & Tiller, "The NURBS Book", 2nd ed., Chapter 2.

#pragma once

#include <nurbs_filler/types.h>

#include <cstddef>
#include <vector>

namespace nurbs_filler {

class KnotVector {
  public:
    KnotVector() = default;

    // Build from an arbitrary non-decreasing sequence. Validation is enforced
    // by Validate(); an invalid vector will throw.
    explicit KnotVector(std::vector<Real> values);

    // Convenience: build a uniform clamped knot vector for given `count`
    // control points (so n = count) and polynomial `degree`. Result:
    //   [0, 0, ..., 0, 1/(n-p), 2/(n-p), ..., (n-p-1)/(n-p), 1, 1, ..., 1]
    static KnotVector UniformClamped(std::size_t count, std::size_t degree);

    // Convenience: build a uniform clamped knot vector with arbitrary
    // start/end parameter values [t_min, t_max]. Useful when the curve lives
    // on a non-unit interval.
    static KnotVector UniformClamped(std::size_t count, std::size_t degree,
                                     Real t_min, Real t_max);

    std::size_t Size() const noexcept { return values_.size(); }
    const std::vector<Real>& Values() const noexcept { return values_; }
    bool Empty() const noexcept { return values_.empty(); }

    // Access a knot value (with bounds check in debug).
    Real operator[](std::size_t i) const;

    // Min / max of the parameter domain.
    Real Front() const noexcept;
    Real Back() const noexcept;

    // Sum of multiplicities of `value` inside the knot vector.
    // Example: [0,0,0,1,2,2,3] has multiplicity 3 at 0.
    std::size_t MultiplicityOf(Real value) const;

    // Find the knot-span index such that u lies in [U[i], U[i+1]).
    // (Piegl & Tiller, Algorithm A2.1).
    // Returns an index in [p, n]. Assumes u in [U.front(), U.back()).
    std::size_t FindSpan(std::size_t n, std::size_t p, Real u) const;

    // Throws std::invalid_argument on violation:
    //   * length < 2
    //   * non-monotone
    //   * not clamped at both ends if p > 0
    void Validate(std::size_t expected_num_ctrlpts, std::size_t expected_degree) const;

  private:
    std::vector<Real> values_;
};

// --------------------------------------------------------------------------
// Chord-length parameterization. Given a poly-line of data points
//   P[0], P[1], ..., P[n-1]
// returns a non-decreasing parameter array with P[0] at t=0 and P[n-1] at t=1.
// "Chord length" means t[i] = (sum_{k=1..i} |P[k]-P[k-1]|) / total_length.
// (Piegl & Tiller, Section 9.2.1 / Algorithm A9.1)
//
// Each `P[i]` must satisfy IsFinite. Input length >= 2.
std::vector<Real> ChordLengthParameters(const std::vector<Vec3>& points);

// Same idea but 2D points.
std::vector<Real> ChordLengthParameters2D(const std::vector<Vec2>& points);

}  // namespace nurbs_filler