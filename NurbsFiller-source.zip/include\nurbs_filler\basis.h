// include/nurbs_filler/basis.h
//
// B-spline basis-function evaluation. We implement the canonical Cox-de
// Boor recursion:
//     N_{i,0}(u) = 1  iff U[i] <= u < U[i+1]  (else 0)
//     N_{i,p}(u) = (u - U[i]) / (U[i+p] - U[i]) * N_{i,p-1}(u)
//                + (U[i+p+1] - u) / (U[i+p+1] - U[i+1]) * N_{i+1,p-1}(u)
//
// For our purposes we evaluate all p+1 non-zero basis functions at u using
// the numerically stable triangular-table scheme (Algorithm A2.2 in
// Piegl & Tiller), which is O(p^2) per evaluation and avoids O(2^p) cost.
//
// References:
//   - Piegl & Tiller, "The NURBS Book", 2nd ed., Section 2.2, Algorithms A2.2.

#pragma once

#include <nurbs_filler/knot_vector.h>
#include <nurbs_filler/types.h>

#include <cstddef>

namespace nurbs_filler {

// Evaluate the `p+1` non-zero B-spline basis functions at parameter `u` and
// return them in `left_to_right` order (i.e. N[u-span] ... N[u-span-p]).
//
// `knot` is the knot vector.
// `span` is the result of KnotVector::FindSpan(n, p, u).
// `p` is the polynomial degree.
// Output array `N_out` must have size p+1.
//
// Time complexity: O(p^2).
void BasisFunctions(const KnotVector& knot, std::size_t span, Real u,
                    std::size_t p, Real* N_out);

// Evaluate all `n+1` B-spline basis functions at parameter `u`.
// Output `N_out` must have size n+1. Most entries will be zero; only p+1
// contiguous entries are non-zero. (Useful for global interpolation.)
//
// `n` is the number of basis functions - 1 (so n = num_control_points - 1).
void AllBasisFunctions(const KnotVector& knot, std::size_t n, std::size_t p,
                       Real u, Real* N_out);

// Evaluate the first derivative of all `n+1` basis functions at `u`.
// Output `dN_out` must have size n+1.
//
// Time complexity: O(p^2).
void AllBasisFunctionDerivatives(const KnotVector& knot, std::size_t n,
                                 std::size_t p, Real u, int k,
                                 Real* dN_out);

// Convenience: compute up to `k`-th derivatives of all basis functions.
// `derivs` is a flat array of size (k+1)*(n+1), laid out as
//     derivs[(j * (n+1)) + i] = N_{i,p}^{(j)}(u)  for j = 0..k
void BasisFunctionDerivativesAll(const KnotVector& knot, std::size_t n,
                                 std::size_t p, Real u, int k, Real* derivs);

}  // namespace nurbs_filler