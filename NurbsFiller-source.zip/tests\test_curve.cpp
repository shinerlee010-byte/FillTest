// tests/test_curve.cpp
#include <nurbs_filler/curve.h>

#include <gtest/gtest.h>

#include <cmath>
#include <vector>

using namespace nurbs_filler;

TEST(Curve, GlobalInterpolationPassesThrough) {
    // 6 data points; cubic (degree 3) interpolation should pass through all.
    std::vector<Vec3> pts;
    for (int i = 0; i < 6; ++i) {
        const Real t = static_cast<Real>(i) / 5.0;
        pts.push_back(Vec3(t, t * t, t * t * t));
    }
    Curve c = Curve::GlobalInterpolation3D(3, pts);
    for (int i = 0; i < 6; ++i) {
        const Real t = static_cast<Real>(i) / 5.0;
        const Vec3 got = c.PointAt(t);
        EXPECT_NEAR(got.x(), pts[i].x(), 1e-8);
        EXPECT_NEAR(got.y(), pts[i].y(), 1e-8);
        EXPECT_NEAR(got.z(), pts[i].z(), 1e-8);
    }
}

TEST(Curve, LeastSquaresReducesError) {
    // Sample a noisy polynomial curve and check the fit error is small.
    std::vector<Vec3> pts;
    for (int i = 0; i <= 40; ++i) {
        const Real t = static_cast<Real>(i) / 40.0;
        pts.push_back(Vec3(t, std::sin(3.0 * t), 0.0));
    }
    Curve c = Curve::LeastSquares3D(3, 8, pts);
    Real max_err = 0;
    for (int i = 0; i <= 40; ++i) {
        const Real t = static_cast<Real>(i) / 40.0;
        const Vec3 got = c.PointAt(t);
        const Vec3 want = pts[i];
        max_err = std::max(max_err, (got - want).norm());
    }
    EXPECT_LT(max_err, 0.02);
}

TEST(Curve, DerivativeMatchesNumerical) {
    std::vector<Vec3> pts;
    for (int i = 0; i < 6; ++i) {
        const Real t = static_cast<Real>(i) / 5.0;
        pts.push_back(Vec3(t, std::cos(t), std::sin(t)));
    }
    Curve c = Curve::GlobalInterpolation3D(3, pts);
    const Real h = 1e-5;
    for (Real t : {0.0, 0.25, 0.5, 0.75, 1.0 - 1e-8}) {
        const Vec3 a = c.PointAt(t + h);
        const Vec3 b = c.PointAt(t - h);
        Vec3 fd = (a - b) / (2 * h);
        Vec3 analytic[1];
        c.DerivativesAt(t, 0, analytic);
        // We only computed C(t); compare C'(t) separately.
        Vec3 deriv;
        c.DerivativesAt(t, 1, &deriv);
        EXPECT_NEAR(deriv.x(), fd.x(), 1e-3) << "t=" << t;
        EXPECT_NEAR(deriv.y(), fd.y(), 1e-3) << "t=" << t;
        EXPECT_NEAR(deriv.z(), fd.z(), 1e-3) << "t=" << t;
    }
}