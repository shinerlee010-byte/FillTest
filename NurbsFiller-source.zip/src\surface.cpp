// src/surface.cpp
#include <nurbs_filler/surface.h>
#include <nurbs_filler/basis.h>

#include <stdexcept>
#include <tuple>

namespace nurbs_filler {

namespace {

// Evaluate S(u, v) using the (pu+1) x (pv+1) non-zero basis function table.
Vec3 EvalSurfaceRational(const std::vector<Real>& Nu,
                          const std::vector<Real>& Nv,
                          std::size_t pu, std::size_t pv,
                          const std::vector<std::vector<ControlPoint4>>& ctrl,
                          std::size_t span_u, std::size_t span_v) {
    Vec3 Aw = Vec3::Zero();
    Real Wv = Real(0);
    for (std::size_t i = 0; i <= pu; ++i) {
        const std::size_t gi = span_u - pu + i;
        const Real Nui = Nu[i];
        for (std::size_t j = 0; j <= pv; ++j) {
            const std::size_t gj = span_v - pv + j;
            const Real Nvj = Nv[j];
            const Real w = ctrl[gi][gj].w;
            Aw += Nui * Nvj * w * ctrl[gi][gj].p;
            Wv += Nui * Nvj * w;
        }
    }
    if (Wv <= Real(0)) {
        throw std::runtime_error("EvalSurfaceRational: zero weight");
    }
    return Aw / Wv;
}

}  // namespace

void Surface::SetDegreeU(std::size_t pu) { pu_ = pu; Validate(); }
void Surface::SetDegreeV(std::size_t pv) { pv_ = pv; Validate(); }
void Surface::SetControlGrid(std::vector<std::vector<ControlPoint4>> grid) {
    ctrl_ = std::move(grid); Validate();
}
void Surface::SetKnotsU(KnotVector ku) { ku_ = std::move(ku); Validate(); }
void Surface::SetKnotsV(KnotVector kv) { kv_ = std::move(kv); Validate(); }

void Surface::Validate() const {
    if (ctrl_.empty()) {
        throw std::invalid_argument("Surface::Validate: empty control grid");
    }
    const std::size_t mu = ctrl_.size();
    const std::size_t mv = ctrl_[0].size();
    for (const auto& row : ctrl_) {
        if (row.size() != mv) {
            throw std::invalid_argument(
                "Surface::Validate: control grid not rectangular");
        }
    }
    if (mu < pu_ + 1 || mv < pv_ + 1) {
        throw std::invalid_argument(
            "Surface::Validate: n_control_points >= degree + 1 per direction");
    }
    ku_.Validate(mu, pu_);
    kv_.Validate(mv, pv_);
    for (const auto& row : ctrl_) {
        for (const auto& cp : row) {
            if (cp.w <= Real(0)) {
                throw std::invalid_argument(
                    "Surface::Validate: weights must be positive");
            }
        }
    }
}

Vec3 Surface::PointAt(Real u, Real v) const {
    const std::size_t nu = NumControlPointsU() - 1;
    const std::size_t nv = NumControlPointsV() - 1;
    const std::size_t su = ku_.FindSpan(nu, pu_, u);
    const std::size_t sv = kv_.FindSpan(nv, pv_, v);
    std::vector<Real> Nu(pu_ + 1), Nv(pv_ + 1);
    BasisFunctions(ku_, su, u, pu_, Nu.data());
    BasisFunctions(kv_, sv, v, pv_, Nv.data());
    return EvalSurfaceRational(Nu, Nv, pu_, pv_, ctrl_, su, sv);
}

void Surface::DerivativesAt(Real u, Real v, int k_total, Vec3* derivs) const {
    // We support up to second-order partial derivatives. The implementation
    // uses Leibniz-rule-based rationalisation (see Algorithm A4.4 in
    // Piegl-Tiller, simplified for k_total <= 2).
    if (k_total < 0) {
        throw std::invalid_argument("Surface::DerivativesAt: k_total < 0");
    }
    if (k_total > 2) {
        throw std::invalid_argument(
            "Surface::DerivativesAt: k_total > 2 not supported in this build");
    }
    const std::size_t nu = NumControlPointsU() - 1;
    const std::size_t nv = NumControlPointsV() - 1;
    const std::size_t su = ku_.FindSpan(nu, pu_, u);
    const std::size_t sv = kv_.FindSpan(nv, pv_, v);

    std::vector<Real> du((k_total + 1) * (nu + 1));
    std::vector<Real> dv((k_total + 1) * (nv + 1));
    BasisFunctionDerivativesAll(ku_, nu, pu_, u, k_total, du.data());
    BasisFunctionDerivativesAll(kv_, nv, pv_, v, k_total, dv.data());

    // A^{(p, q)} = sum_{i, j} dNu[p][i] dNv[q][j] w_{ij} P_{ij}
    // W^{(p, q)} = sum_{i, j} dNu[p][i] dNv[q][j] w_{ij}
    // stored as A[p * K + q] and W[p * K + q] with K = k_total+1.
    const int K = k_total + 1;
    std::vector<Vec3> A(K * K, Vec3::Zero());
    std::vector<Real> W(K * K, Real(0));
    for (int p_idx = 0; p_idx <= k_total; ++p_idx) {
        for (int q_idx = 0; q_idx <= k_total; ++q_idx) {
            Vec3 a = Vec3::Zero();
            Real w = Real(0);
            for (std::size_t i = 0; i <= nu; ++i) {
                const std::size_t gi = su - pu_ + i;
                for (std::size_t j = 0; j <= nv; ++j) {
                    const std::size_t gj = sv - pv_ + j;
                    const Real wt = ctrl_[gi][gj].w;
                    const Real dNu = du[p_idx * (nu + 1) + i];
                    const Real dNv = dv[q_idx * (nv + 1) + j];
                    a += dNu * dNv * wt * ctrl_[gi][gj].p;
                    w += dNu * dNv * wt;
                }
            }
            A[p_idx * K + q_idx] = a;
            W[p_idx * K + q_idx] = w;
        }
    }

    // Apply Leibniz's 2D quotient rule:
    //   S^{(p, q)} = (1/W^{0,0}) * sum_{k=0..p, l=0..q}
    //                  binom(p, k) binom(q, l) A^{(k, l)} (-W)^{(p-k, q-l)}
    // where (-W)^{(r, s)} is the (r, s) partial derivative of (-W), which
    // equals -W^{(r, s)} for (r, s) != (0, 0).
    auto Wp = [&](int p_idx, int q_idx) -> Real {
        return W[p_idx * K + q_idx];
    };

    // For k_total <= 2 we can do this directly. The mixed partials of -W
    // are simply -W^{(r, s)} so:
    for (int p_idx = 0; p_idx <= k_total; ++p_idx) {
        for (int q_idx = 0; q_idx <= k_total - p_idx; ++q_idx) {
            Vec3 num = Vec3::Zero();
            // Iterate over (k, l) with k+l <= p+q and compute the
            // contribution. We use the identity:
            //   (-W)^{(p-k, q-l)} = (-1)^{(p-k)+(q-l)} (p-k)!(q-l)!/(... )*W^{...}
            // In practice, just iterate over all (k, l) with k <= p, l <= q.
            for (int k = 0; k <= p_idx; ++k) {
                for (int l = 0; l <= q_idx; ++l) {
                    // Binomial coefficient for two-variable Leibniz:
                    Real coeff = Real(1);
                    // binom(p_idx, k) * binom(q_idx, l) =
                    for (int r = p_idx - k + 1; r <= p_idx; ++r) coeff *= r;
                    for (int r = 1; r <= k; ++r) coeff /= r;
                    for (int r = q_idx - l + 1; r <= q_idx; ++r) coeff *= r;
                    for (int r = 1; r <= l; ++r) coeff /= l;

                    // (-W)^{(p-k, q-l)}: We need the (p-k, q-l) partial
                    // derivative of -W = -1 * W. Use the Leibniz-sum identity
                    // for derivative of a product:
                    //   (-W)^{(r, s)} = sum over partitions of (r, s)...
                    // For small r+s this is just W^{(r, s)} with appropriate
                    // sign: only one term survives when (r, s) is a single
                    // multi-index, which it is. So:
                    //   (-W)^{(r, s)} = -W^{(r, s)}
                    // Note: there's no sum over partitions because we
                    // differentiate a single variable (-W) of two args.
                    const int r_p = p_idx - k;
                    const int r_q = q_idx - l;
                    const Real negW_partial = -Wp(r_p, r_q);
                    num += coeff * A[k * K + l] * negW_partial;
                }
            }
            // Divide by W^{0, 0}
            if (Wp(0, 0) == Real(0)) {
                throw std::runtime_error(
                    "Surface::DerivativesAt: zero weight denominator");
            }
            derivs[p_idx * K + q_idx] = num / Wp(0, 0);
        }
    }
}

std::vector<std::tuple<Real, Real, Vec3>> Surface::Sample(std::size_t nu,
                                                            std::size_t nv) const {
    std::vector<std::tuple<Real, Real, Vec3>> out;
    out.reserve(nu * nv);
    const Real du = (ku_.Back() - ku_.Front()) / (nu - 1);
    const Real dv = (kv_.Back() - kv_.Front()) / (nv - 1);
    for (std::size_t i = 0; i < nu; ++i) {
        const Real u = ku_.Front() + du * static_cast<Real>(i);
        for (std::size_t j = 0; j < nv; ++j) {
            const Real v = kv_.Front() + dv * static_cast<Real>(j);
            out.emplace_back(u, v, PointAt(u, v));
        }
    }
    return out;
}

void Surface::Triangulate(std::size_t nu, std::size_t nv,
                          std::vector<Vec3>* positions,
                          std::vector<std::array<std::size_t, 3>>* triangles) const {
    positions->clear();
    triangles->clear();
    positions->reserve(nu * nv);
    const Real du = (ku_.Back() - ku_.Front()) / (nu - 1);
    const Real dv = (kv_.Back() - kv_.Front()) / (nv - 1);
    for (std::size_t i = 0; i < nu; ++i) {
        const Real u = ku_.Front() + du * static_cast<Real>(i);
        for (std::size_t j = 0; j < nv; ++j) {
            const Real v = kv_.Front() + dv * static_cast<Real>(j);
            positions->push_back(PointAt(u, v));
        }
    }
    for (std::size_t i = 0; i + 1 < nu; ++i) {
        for (std::size_t j = 0; j + 1 < nv; ++j) {
            const std::size_t v00 = i * nv + j;
            const std::size_t v01 = i * nv + (j + 1);
            const std::size_t v11 = (i + 1) * nv + (j + 1);
            const std::size_t v10 = (i + 1) * nv + j;
            triangles->push_back({v00, v01, v11});
            triangles->push_back({v00, v11, v10});
        }
    }
}

Surface Surface::GlobalInterpolationGrid(
    std::size_t pu, std::size_t pv,
    const std::vector<std::vector<Vec3>>& grid) {
    if (grid.empty() || grid[0].empty()) {
        throw std::invalid_argument("GlobalInterpolationGrid: empty grid");
    }
    const std::size_t mu = grid.size();
    const std::size_t mv = grid[0].size();
    for (const auto& row : grid) {
        if (row.size() != mv) throw std::invalid_argument("non-rectangular grid");
    }
    if (mu < pu + 1 || mv < pv + 1) {
        throw std::invalid_argument(
            "GlobalInterpolationGrid: grid must be >= degree+1 per direction");
    }

    // Interpolate each row of points as a curve in u, then each column
    // of the resulting control points as a curve in v.
    std::vector<Curve> curves_u(mu);
    for (std::size_t i = 0; i < mu; ++i) {
        curves_u[i] = Curve::GlobalInterpolation3D(pu, grid[i]);
    }
    std::vector<std::vector<Vec3>> cols(mv, std::vector<Vec3>(mu));
    for (std::size_t i = 0; i < mu; ++i) {
        const auto& cps = curves_u[i].ControlPoints();
        for (std::size_t j = 0; j < mv; ++j) {
            cols[j][i] = cps[j].p;
        }
    }
    std::vector<Curve> curves_v(mv);
    for (std::size_t j = 0; j < mv; ++j) {
        curves_v[j] = Curve::GlobalInterpolation3D(pv, cols[j]);
    }

    std::vector<std::vector<ControlPoint4>> grid_out(mu, std::vector<ControlPoint4>(mv));
    for (std::size_t i = 0; i < mu; ++i) {
        for (std::size_t j = 0; j < mv; ++j) {
            grid_out[i][j] = ControlPoint4(curves_v[j].ControlPoints()[i].p);
        }
    }
    KnotVector ku = curves_u[0].Knots();
    KnotVector kv = curves_v[0].Knots();
    return Surface(pu, pv, std::move(grid_out), std::move(ku), std::move(kv));
}

Surface Surface::LeastSquaresGrid(std::size_t pu, std::size_t pv,
                                    std::size_t n_ctrl_u, std::size_t n_ctrl_v,
                                    const std::vector<std::vector<Vec3>>& grid) {
    if (grid.empty() || grid[0].empty()) {
        throw std::invalid_argument("LeastSquaresGrid: empty grid");
    }
    const std::size_t mu = grid.size();
    const std::size_t mv = grid[0].size();
    if (n_ctrl_u < pu + 1 || n_ctrl_v < pv + 1) {
        throw std::invalid_argument("LeastSquaresGrid: ctrl >= degree+1");
    }
    n_ctrl_u = std::min(n_ctrl_u, mu);
    n_ctrl_v = std::min(n_ctrl_v, mv);

    // Tensor-product least squares (Piegl-Tiller Section 9.5.1).
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> N(mu, n_ctrl_u);
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> M(mv, n_ctrl_v);
    std::vector<Real> Nu(pu + 1), Nv(pv + 1);
    {
        KnotVector ku = KnotVector::UniformClamped(n_ctrl_u, pu);
        for (std::size_t i = 0; i < mu; ++i) {
            N.row(i).setZero();
            const Real t = static_cast<Real>(i) / static_cast<Real>(mu - 1);
            const std::size_t span = ku.FindSpan(n_ctrl_u - 1, pu, t);
            BasisFunctions(ku, span, t, pu, Nu.data());
            const std::size_t offset = span - pu;
            for (std::size_t j = 0; j <= pu; ++j) N(i, offset + j) = Nu[j];
        }
    }
    {
        KnotVector kv = KnotVector::UniformClamped(n_ctrl_v, pv);
        for (std::size_t j = 0; j < mv; ++j) {
            M.row(j).setZero();
            const Real t = static_cast<Real>(j) / static_cast<Real>(mv - 1);
            const std::size_t span = kv.FindSpan(n_ctrl_v - 1, pv, t);
            BasisFunctions(kv, span, t, pv, Nv.data());
            const std::size_t offset = span - pv;
            for (std::size_t l = 0; l <= pv; ++l) M(j, offset + l) = Nv[l];
        }
    }

    // (N^T N)^-1 N^T  via LDLT
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Q =
        (N.transpose() * N).ldlt().solve(N.transpose());
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> R =
        (M.transpose() * M).ldlt().solve(M.transpose());

    // Step 1: solve for control points along u, per column of v
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Pctrl_u(
        n_ctrl_u, mv * 3);
    for (std::size_t j = 0; j < mv; ++j) {
        Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> col(mu, 3);
        for (std::size_t i = 0; i < mu; ++i) col.row(i) = grid[i][j].transpose();
        Pctrl_u.block(0, j * 3, n_ctrl_u, 3) = Q * col;
    }
    // Step 2: solve for control points along v, per row of u
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Pctrl(n_ctrl_u * n_ctrl_v, 3);
    for (std::size_t i = 0; i < n_ctrl_u; ++i) {
        Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> row(mv, 3);
        for (std::size_t j = 0; j < mv; ++j) {
            row.row(j) = Pctrl_u.block(i, j * 3, 1, 3);
        }
        Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> v_row = R * row;
        for (std::size_t j = 0; j < n_ctrl_v; ++j) {
            Pctrl.row(i * n_ctrl_v + j) = v_row.row(j);
        }
    }
    std::vector<std::vector<ControlPoint4>> ctrl_out(
        n_ctrl_u, std::vector<ControlPoint4>(n_ctrl_v));
    for (std::size_t i = 0; i < n_ctrl_u; ++i) {
        for (std::size_t j = 0; j < n_ctrl_v; ++j) {
            const Vec3 p = Pctrl.row(i * n_ctrl_v + j).transpose();
            ctrl_out[i][j] = ControlPoint4(p);
        }
    }
    KnotVector ku = KnotVector::UniformClamped(n_ctrl_u, pu);
    KnotVector kv = KnotVector::UniformClamped(n_ctrl_v, pv);
    return Surface(pu, pv, std::move(ctrl_out), std::move(ku), std::move(kv));
}

}  // namespace nurbs_filler