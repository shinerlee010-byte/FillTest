// include/nurbs_filler/surface.h
//
// Rational B-spline surfaces. A surface is parameterised by (u, v) and is
// built as the tensor product of two NURBS curves:
//     S(u, v) = sum_{i,j} R_{i,pu}(u) * R_{j,pv}(v) * P_{ij, w}
//
// where R are the rational basis functions and P_{ij,w} are control points
// in homogeneous coordinates.
//
// References:
//   Piegl L., Tiller W. "The NURBS Book", 2nd ed., Springer 1997,
//   Chapter 4.

#pragma once

#include <nurbs_filler/curve.h>
#include <nurbs_filler/knot_vector.h>
#include <nurbs_filler/types.h>

#include <cstddef>
#include <vector>

namespace nurbs_filler {

class Surface {
  public:
    Surface() = default;
    Surface(std::size_t pu, std::size_t pv,
            std::vector<std::vector<ControlPoint4>> control_grid,
            KnotVector ku, KnotVector kv)
    : pu_(pu), pv_(pv),
      ctrl_(std::move(control_grid)),
      ku_(std::move(ku)), kv_(std::move(kv)) {
        Validate();
    }

    std::size_t DegreeU() const noexcept { return pu_; }
    std::size_t DegreeV() const noexcept { return pv_; }
    std::size_t NumControlPointsU() const noexcept { return ctrl_.size(); }
    std::size_t NumControlPointsV() const noexcept {
        return ctrl_.empty() ? 0 : ctrl_[0].size();
    }
    const std::vector<std::vector<ControlPoint4>>& ControlGrid() const noexcept {
        return ctrl_;
    }
    const KnotVector& KnotsU() const noexcept { return ku_; }
    const KnotVector& KnotsV() const noexcept { return kv_; }

    void SetDegreeU(std::size_t pu);
    void SetDegreeV(std::size_t pv);
    void SetControlGrid(std::vector<std::vector<ControlPoint4>> grid);
    void SetKnotsU(KnotVector ku);
    void SetKnotsV(KnotVector kv);

    // Evaluate S(u, v).
    Vec3 PointAt(Real u, Real v) const;

    // Evaluate up to k-th partial derivatives.
    // Layout: derivs[k_total*(k_total+3)/2 + ...] is avoided. We use
    // a simple linear layout:
    //     derivs[((du) * (k_total+1) + dv) * 3 + axis] = S^{(du, dv)}(u, v)
    // where k_total is the highest total derivative order.
    void DerivativesAt(Real u, Real v, int k_total, Vec3* derivs) const;

    // Sample the surface on a regular u x v grid, returning a list of
    // (u_i, v_j, point) tuples.
    std::vector<std::tuple<Real, Real, Vec3>> Sample(std::size_t nu,
                                                     std::size_t nv) const;

    // Triangulate the surface as a regular grid of triangles. Useful for
    // visualisation tools (OBJ/STL exporters). Returns a flat index array:
    // [v00, v01, v11, v00, v11, v10] for each quad.
    void Triangulate(std::size_t nu, std::size_t nv,
                     std::vector<Vec3>* positions,
                     std::vector<std::array<std::size_t, 3>>* triangles) const;

    // Throw on inconsistency.
    void Validate() const;

    // Static constructors ------------------------------------------------
    // Build a tensor-product surface that interpolates a regular grid of
    // 3D points. Both directions use chord-length parameterisation and
    // uniform clamped knots. Throws if grid is not rectangular.
    static Surface GlobalInterpolationGrid(std::size_t pu, std::size_t pv,
                                          const std::vector<std::vector<Vec3>>& grid);

    // Least-squares approximation of a regular grid of 3D points.
    // n_ctrl_u, n_ctrl_v can be < grid size (smoothing) or > (won't help,
    // we cap at grid size).
    static Surface LeastSquaresGrid(std::size_t pu, std::size_t pv,
                                    std::size_t n_ctrl_u, std::size_t n_ctrl_v,
                                    const std::vector<std::vector<Vec3>>& grid);

  private:
    std::size_t pu_ = 3;
    std::size_t pv_ = 3;
    std::vector<std::vector<ControlPoint4>> ctrl_;
    KnotVector ku_;
    KnotVector kv_;
};

}  // namespace nurbs_filler