// include/nurbs_filler/curve.h
//
// Rational and non-rational B-spline curves.
//
// A (rational) B-spline curve is defined by:
//     C(u) = sum_{i=0..n} R_{i,p}(u) * P_i_w
// where
//     R_{i,p}(u) = N_{i,p}(u) * w_i / sum_j N_{j,p}(u) * w_j
// and P_i_w is the i-th control point expressed in homogeneous (4D)
// coordinates {w_i * P_i, w_i}. The "weights" allow us to model conic
// sections exactly.
//
// References:
//   Piegl L., Tiller W. "The NURBS Book", 2nd ed., Springer 1997,
//   Chapter 4.

#pragma once

#include <nurbs_filler/knot_vector.h>
#include <nurbs_filler/types.h>

#include <cstddef>
#include <vector>

namespace nurbs_filler {

// A 4D "homogeneous" point: {x*w, y*w, z*w, w}.
// We store the 3D point and the weight separately for clarity; the
// Curve class multiplies them internally as needed.
struct ControlPoint4 {
    Vec3 p;
    Real w = Real(1);

    ControlPoint4() = default;
    ControlPoint4(const Vec3& pt, Real weight = Real(1)) : p(pt), w(weight) {}

    // Convenience: Euclidean representation.
    Vec3 Euclidean() const { return p; }
};

// Forward declaration: a Curve is the 1D version of a Surface.
class Curve {
  public:
    Curve() = default;
    Curve(std::size_t degree, std::vector<ControlPoint4> control_points,
          KnotVector knots)
    : p_(degree), ctrl_(std::move(control_points)), kv_(std::move(knots)) {
        Validate();
    }

    std::size_t Degree() const noexcept { return p_; }
    std::size_t NumControlPoints() const noexcept { return ctrl_.size(); }
    const std::vector<ControlPoint4>& ControlPoints() const noexcept { return ctrl_; }
    const KnotVector& Knots() const noexcept { return kv_; }

    // Change the polynomial degree.
    void SetDegree(std::size_t degree);
    void SetControlPoints(std::vector<ControlPoint4> cps);
    void SetKnots(KnotVector kv);

    // Evaluate C(u) at a single parameter.
    Vec3 PointAt(Real u) const;

    // Evaluate C'(u), C''(u), ... up to k-th derivative.
    // `derivs` is an array of size k+1.
    void DerivativesAt(Real u, int k, Vec3* derivs) const;

    // Raise/lower degree (Boehm-style, degree elevation only).
    // Currently NOT implemented; reserved.
    // void ElevateDegree(std::size_t t);

    // Sanity checks: throws std::invalid_argument on inconsistency.
    void Validate() const;

    // ---------- Static constructors ----------------------------------
    // Build a clamped B-spline curve that interpolates the given 3D
    // points. Parameters are chosen by chord-length.
    //
    // Throws std::invalid_argument on insufficient input.
    static Curve GlobalInterpolation3D(std::size_t degree,
                                       const std::vector<Vec3>& points);

    // Build a clamped B-spline curve that interpolates the given 2D
    // points (Z component implicitly 0).
    static Curve GlobalInterpolation2D(std::size_t degree,
                                       const std::vector<Vec2>& points);

    // Build a clamped B-spline curve of dimension (`n_ctrl`) that
    // approximates the given 3D points in the least-squares sense.
    // Uses chord-length parameterization and uniform knots.
    //
    // Throws if n_ctrl < degree + 1 or points.size() < n_ctrl.
    static Curve LeastSquares3D(std::size_t degree, std::size_t n_ctrl,
                               const std::vector<Vec3>& points);

  private:
    std::size_t p_ = 3;
    std::vector<ControlPoint4> ctrl_;
    KnotVector kv_;
};

// Two non-equal knot vectors can be used to compare curves.
inline bool operator==(const Curve& a, const Curve& b) {
    return a.Degree() == b.Degree() &&
           a.NumControlPoints() == b.NumControlPoints() &&
           a.ControlPoints() == b.ControlPoints() &&
           a.Knots().Values() == b.Knots().Values();
}

}  // namespace nurbs_filler