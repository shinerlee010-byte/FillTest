// src/curve.cpp
#include <nurbs_filler/curve.h>
#include <nurbs_filler/basis.h>

#include <Eigen/Dense>

#include <stdexcept>

namespace nurbs_filler {

namespace {

// Evaluate C(u) from basis functions and control points.
// Layout: ders is (k+1) * (n+1) where n = ctrl.size() - 1.
Vec3 EvalRational(const std::vector<Real>& ders, int k, int n,
                  const std::vector<ControlPoint4>& ctrl) {
    // We compute A_k(u) and W_k(u) following Algorithm A4.2:
    //   A(u) = sum N_{i,p}^{(0)} w_i P_i   (weighted point in 3D, treated as 3D
    //                                        vector multiplied by weight)
    //   B(u) = sum N_{i,p}^{(0)} w_i       (denominator)
    //   C(u) = A(u) / B(u)
    //
    // For derivatives use the binomial expansion (A4.3):
    //   C^{(k)}(u) = (1 / B) * sum_{j=0..k} binomial(k, j) * A^{(j)} * (-W)^{(k-j)}
    //
    // where A^{(j)} and W^{(j)} are the weighted derivatives of numerator
    // and denominator, computed from ders multiplied by w_i.

    auto aw = [&](int j) -> Vec3 {
        Vec3 s = Vec3::Zero();
        for (int i = 0; i <= n; ++i) {
            const Real w = ctrl[i].w;
            s += ders[j * (n + 1) + i] * w * ctrl[i].p;
        }
        return s;
    };
    auto wv = [&](int j) -> Real {
        Real s = 0;
        for (int i = 0; i <= n; ++i) {
            s += ders[j * (n + 1) + i] * ctrl[i].w;
        }
        return s;
    };

    const Real W0 = wv(0);
    if (W0 <= Real(0)) {
        throw std::runtime_error("Curve::EvalRational: non-positive weight sum");
    }
    const Vec3 C0 = aw(0) / W0;

    if (k == 0) return C0;

    // Binomial coefficients up to k
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> bin;
    bin.resize(k + 1, k + 1);
    bin.setZero();
    bin(0, 0) = 1;
    for (int j = 1; j <= k; ++j) {
        bin(j, 0) = 1;
        bin(j, j) = 1;
        for (int r = 1; r < j; ++r) bin(j, r) = bin(j - 1, r - 1) + bin(j - 1, r);
    }

    Eigen::Matrix<Real, Eigen::Dynamic, 1> CK(k + 1);
    CK.setZero();
    Vec3 curA = aw(0);
    Real curW = wv(0);
    Vec3 prevA[k + 1];
    Real prevW[k + 1];
    for (int j = 0; j <= k; ++j) {
        prevA[j] = aw(j);
        prevW[j] = wv(j);
    }

    Vec3 result[k + 1];
    result[0] = C0;

    for (int kk = 1; kk <= k; ++kk) {
        Vec3 s = Vec3::Zero();
        for (int j = 0; j <= kk; ++j) {
            const Real c = bin(kk, j) * prevA[j];
            // (-W)^{(kk-j)}:
            Real w_pow = 0;
            if (kk - j == 0) {
                w_pow = Real(1);
            } else {
                Real prod = Real(1);
                for (int t = 0; t <= kk - j - 1; ++t) prod *= prevW[t];
                // alternating signs (-1)^{kk-j}
                if ((kk - j) % 2 == 1) prod = -prod;
                w_pow = prod;
            }
            s += c * w_pow;
        }
        result[kk] = s / prevW[0];
    }
    return result[k];
}

}  // namespace

void Curve::SetDegree(std::size_t degree) {
    p_ = degree;
    Validate();
}

void Curve::SetControlPoints(std::vector<ControlPoint4> cps) {
    ctrl_ = std::move(cps);
    Validate();
}

void Curve::SetKnots(KnotVector kv) {
    kv_ = std::move(kv);
    Validate();
}

void Curve::Validate() const {
    if (ctrl_.empty()) {
        throw std::invalid_argument("Curve::Validate: empty control points");
    }
    if (ctrl_.size() < p_ + 1) {
        throw std::invalid_argument(
            "Curve::Validate: need n_control_points >= degree + 1");
    }
    kv_.Validate(ctrl_.size(), p_);
    for (const auto& c : ctrl_) {
        if (c.w <= Real(0)) {
            throw std::invalid_argument(
                "Curve::Validate: weights must be positive");
        }
    }
}

Vec3 Curve::PointAt(Real u) const {
    const std::size_t n = ctrl_.size() - 1;
    const int kk = 0;
    std::vector<Real> ders((kk + 1) * (n + 1));
    BasisFunctionDerivativesAll(kv_, n, p_, u, kk, ders.data());
    return EvalRational(ders, kk, static_cast<int>(n), ctrl_);
}

void Curve::DerivativesAt(Real u, int k, Vec3* derivs) const {
    if (k < 0) throw std::invalid_argument("Curve::DerivativesAt: k must be >= 0");
    const std::size_t n = ctrl_.size() - 1;
    std::vector<Real> ders((k + 1) * (n + 1));
    BasisFunctionDerivativesAll(kv_, n, p_, u, k, ders.data());
    // Re-implement EvalRational so it returns all k+1 derivatives:
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> bin;
    bin.resize(k + 1, k + 1);
    bin.setZero();
    bin(0, 0) = 1;
    for (int j = 1; j <= k; ++j) {
        bin(j, 0) = 1;
        bin(j, j) = 1;
        for (int r = 1; r < j; ++r) bin(j, r) = bin(j - 1, r - 1) + bin(j - 1, r);
    }

    std::vector<Vec3> Aw(k + 1, Vec3::Zero());
    std::vector<Real> Wv(k + 1, Real(0));
    for (int j = 0; j <= k; ++j) {
        Vec3 s = Vec3::Zero();
        Real w = 0;
        for (std::size_t i = 0; i <= n; ++i) {
            const Real weight = ctrl_[i].w;
            s += ders[j * (n + 1) + i] * weight * ctrl_[i].p;
            w += ders[j * (n + 1) + i] * weight;
        }
        Aw[j] = s;
        Wv[j] = w;
    }

    std::vector<Vec3> Ck(k + 1, Vec3::Zero());
    for (int kk = 0; kk <= k; ++kk) {
        Vec3 s = Vec3::Zero();
        for (int j = 0; j <= kk; ++j) {
            const Real c = bin(kk, j) * Aw[j];
            // (-W)^{(kk-j)} = product of (-W)^{(t)} for t=1..(kk-j)
            // using the convention W^{(0)} = W, W^{(t)} = Wv[t].
            Real w_pow;
            if (kk - j == 0) {
                w_pow = Real(1);
            } else {
                Real prod = Real(1);
                for (int t = 1; t <= kk - j; ++t) prod *= Wv[t];
                if ((kk - j) % 2 == 1) prod = -prod;
                w_pow = prod;
            }
            s += c * w_pow;
        }
        if (Wv[0] == Real(0)) {
            throw std::runtime_error("Curve::DerivativesAt: zero weight");
        }
        Ck[kk] = s / Wv[0];
    }
    for (int kk = 0; kk <= k; ++kk) derivs[kk] = Ck[kk];
}

Curve Curve::GlobalInterpolation3D(std::size_t degree,
                                    const std::vector<Vec3>& points) {
    if (points.size() < degree + 1) {
        throw std::invalid_argument(
            "Curve::GlobalInterpolation3D: need >= degree + 1 points");
    }
    const std::size_t n = points.size() - 1;
    const std::vector<Real> t = ChordLengthParameters(points);
    KnotVector kv = KnotVector::UniformClamped(n + 1, degree);

    // Solve for control points by linear system: N(t_i) * P_ctrl = P_data.
    // Build N as a (n+1) x (n+1) matrix (each row sums to 1 because of
    // clamped knots).
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Nmat(n + 1, n + 1);
    std::vector<Real> Nloc(degree + 1);
    for (std::size_t i = 0; i <= n; ++i) {
        std::fill(Nmat.row(i).begin(), Nmat.row(i).end(), Real(0));
        const std::size_t span = kv.FindSpan(n, degree, t[i]);
        BasisFunctions(kv, span, t[i], degree, Nloc.data());
        // Place the local basis at the appropriate global positions.
        // For a clamped knot vector, span(i) = p for the first few interior
        // parameters; for t[i] == 1 we need special handling. We treat
        // t[i] == 1 as u = 1 - tiny_eps.
        const std::size_t offset = span - degree;
        for (std::size_t j = 0; j <= degree; ++j) {
            Nmat(i, offset + j) = Nloc[j];
        }
    }

    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> rhs(n + 1, 3);
    for (std::size_t i = 0; i <= n; ++i) {
        rhs.row(i) = points[i].transpose();
    }

    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> P =
        Nmat.colPivHouseholderQr().solve(rhs);

    std::vector<ControlPoint4> cps(n + 1);
    for (std::size_t i = 0; i <= n; ++i) {
        cps[i] = ControlPoint4(P.row(i).transpose());
    }
    return Curve(degree, std::move(cps), std::move(kv));
}

Curve Curve::GlobalInterpolation2D(std::size_t degree,
                                    const std::vector<Vec2>& points) {
    std::vector<Vec3> pts3(points.size());
    for (std::size_t i = 0; i < points.size(); ++i) {
        pts3[i] = Vec3(points[i](0), points[i](1), Real(0));
    }
    return GlobalInterpolation3D(degree, pts3);
}

Curve Curve::LeastSquares3D(std::size_t degree, std::size_t n_ctrl,
                            const std::vector<Vec3>& points) {
    if (n_ctrl < degree + 1) {
        throw std::invalid_argument(
            "Curve::LeastSquares3D: need n_ctrl >= degree + 1");
    }
    if (points.size() < n_ctrl) {
        throw std::invalid_argument(
            "Curve::LeastSquares3D: need >= n_ctrl data points");
    }
    const std::size_t m = points.size();
    const std::size_t n = n_ctrl - 1;
    const std::vector<Real> t = ChordLengthParameters(points);
    KnotVector kv = KnotVector::UniformClamped(n_ctrl, degree);

    // Solve least squares: min || N * P_ctrl - P_data ||^2
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Nmat(m, n_ctrl);
    std::vector<Real> Nloc(degree + 1);
    for (std::size_t i = 0; i < m; ++i) {
        std::fill(Nmat.row(i).begin(), Nmat.row(i).end(), Real(0));
        const std::size_t span = kv.FindSpan(n, degree, t[i]);
        BasisFunctions(kv, span, t[i], degree, Nloc.data());
        const std::size_t offset = span - degree;
        for (std::size_t j = 0; j <= degree; ++j) {
            Nmat(i, offset + j) = Nloc[j];
        }
    }
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> rhs(m, 3);
    for (std::size_t i = 0; i < m; ++i) rhs.row(i) = points[i].transpose();

    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> P =
        Nmat.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(rhs);

    std::vector<ControlPoint4> cps(n_ctrl);
    for (std::size_t i = 0; i < n_ctrl; ++i) {
        cps[i] = ControlPoint4(P.row(i).transpose());
    }
    return Curve(degree, std::move(cps), std::move(kv));
}

}  // namespace nurbs_filler