// tests/test_knot_vector.cpp
#include <nurbs_filler/knot_vector.h>

#include <gtest/gtest.h>

#include <vector>

using namespace nurbs_filler;

TEST(KnotVector, UniformClampedBasic) {
    // Cubic (degree 3) clamped with 6 control points:
    // n = 5, p = 3, m = 9
    // [0,0,0,0, 0.5, 1,1,1,1]
    auto kv = KnotVector::UniformClamped(6, 3);
    EXPECT_EQ(kv.Size(), 9u);
    EXPECT_DOUBLE_EQ(kv.Front(), 0.0);
    EXPECT_DOUBLE_EQ(kv.Back(), 1.0);
    EXPECT_EQ(kv.MultiplicityOf(0.0), 4u);
    EXPECT_EQ(kv.MultiplicityOf(1.0), 4u);
    EXPECT_DOUBLE_EQ(kv[4], 0.5);
}

TEST(KnotVector, UniformClampedNonUnit) {
    auto kv = KnotVector::UniformClamped(4, 2, -2.0, 5.0);
    EXPECT_EQ(kv.Size(), 7u);
    EXPECT_DOUBLE_EQ(kv.Front(), -2.0);
    EXPECT_DOUBLE_EQ(kv.Back(), 5.0);
    EXPECT_EQ(kv.MultiplicityOf(-2.0), 3u);
    EXPECT_EQ(kv.MultiplicityOf(5.0), 3u);
}

TEST(KnotVector, FindSpanBoundaries) {
    auto kv = KnotVector::UniformClamped(6, 3);  // n=5, p=3
    EXPECT_EQ(kv.FindSpan(5, 3, 0.0), 3u);
    EXPECT_EQ(kv.FindSpan(5, 3, 0.5), 4u);
    EXPECT_EQ(kv.FindSpan(5, 3, 1.0), 5u);  // clamped at 1.0
}

TEST(KnotVector, ValidatePasses) {
    auto kv = KnotVector::UniformClamped(8, 3);
    EXPECT_NO_THROW(kv.Validate(8, 3));
}

TEST(KnotVector, ValidateRejectsBadLength) {
    auto kv = KnotVector::UniformClamped(6, 3);
    EXPECT_THROW(kv.Validate(7, 3), std::invalid_argument);
}

TEST(ChordLengthParameters, EqualSpacing) {
    // For uniformly spaced points along x-axis, the parameter values
    // should be 0, 1/n, 2/n, ..., 1.
    std::vector<Vec3> pts;
    for (int i = 0; i <= 10; ++i) pts.push_back(Vec3(static_cast<Real>(i), 0, 0));
    auto t = ChordLengthParameters(pts);
    ASSERT_EQ(t.size(), pts.size());
    EXPECT_NEAR(t.front(), 0.0, Tolerance::kEps);
    EXPECT_NEAR(t.back(), 1.0, Tolerance::kEps);
    for (std::size_t i = 1; i < t.size(); ++i) {
        EXPECT_NEAR(t[i] - t[i - 1], 0.1, Tolerance::kEps);
    }
}

TEST(ChordLengthParameters, RejectsDuplicates) {
    std::vector<Vec3> pts = {Vec3(0, 0, 0), Vec3(0, 0, 0)};
    EXPECT_THROW(ChordLengthParameters(pts), std::invalid_argument);
}