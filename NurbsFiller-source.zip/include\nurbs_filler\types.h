// include/nurbs_filler/types.h
// Basic linear-algebra and small numeric types.
//
// We deliberately keep this layer tiny so the rest of the library reads
// like standard numerical-recipes pseudocode.

#pragma once

#include <Eigen/Dense>
#include <cstddef>
#include <cstdint>

namespace nurbs_filler {

// Real scalar used throughout.
using Real = double;

// A point in 3D space. Column-vector for affine compatibility with Eigen.
using Vec3 = Eigen::Matrix<Real, 3, 1>;

// Homogeneous 2D point (used for planar parameter ranges).
using Vec2 = Eigen::Matrix<Real, 2, 1>;

// Dynamic row vector (e.g. for knot vectors, B-spline coefficient arrays).
using RowVecX = Eigen::Matrix<Real, Eigen::Dynamic, 1, Eigen::RowMajor>;

// Dynamic dense matrix.
template <typename Scalar = Real>
using MatrixX = Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic>;

// A small helper used by tolerance-bearing comparisons.
struct Tolerance {
    static constexpr Real kEps = static_cast<Real>(1e-9);
    static constexpr Real kLoose = static_cast<Real>(1e-6);
};

}  // namespace nurbs_filler