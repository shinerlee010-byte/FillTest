// src/fitting.cpp
//
// Constrained NURBS surface fitting implementation.
//
// Strategy:
//   1. Choose knot vectors uniformly clamped over [0, 1] in both u and v
//      with the requested number of control points.
//   2. Build the (n_constraints) x (n_ctrl_u * n_ctrl_v) basis-function
//      matrix N where each row is the kron product of basis(u) and basis(v)
//      evaluated at that constraint's parameter location.
//   3. Solve the weighted least-squares system with hard constraints
//      folded in via penalty weighting: minimise
//         sum_i w_i * ||N_i x - P_i||^2
//             + sum_h lambda_h * ||N_h x - P_h||^2
//             + ridge * ||x||^2
//      where x is the flattened 3D vector of control point coordinates.
//   4. Reshape x back into a (n_ctrl_u, n_ctrl_v) grid of ControlPoint4.

#include <nurbs_filler/basis.h>
#include <nurbs_filler/fitting.h>
#include <nurbs_filler/knot_vector.h>

#include <Eigen/Dense>

#include <algorithm>
#include <cstddef>
#include <stdexcept>

namespace nurbs_filler {

namespace {

struct ConstraintRow {
    Real u;
    Real v;
    Vec3 p;
    Real w;            // effective weight (>= 0). 0 -> skip row entirely.
};

// Build the basis function row for a constraint at parameter (u, v):
// the kron-product of basis(pu) and basis(pv), size n_ctrl_u * n_ctrl_v.
Eigen::RowVectorX BuildBasisRow(const KnotVector& ku, const KnotVector& kv,
                                std::size_t pu, std::size_t pv,
                                std::size_t nu, std::size_t nv,
                                Real u, Real v,
                                std::vector<Real>& Nu, std::vector<Real>& Nv) {
    const std::size_t su = ku.FindSpan(nu, pu, u);
    const std::size_t sv = kv.FindSpan(nv, pv, v);
    BasisFunctions(ku, su, u, pu, Nu.data());
    BasisFunctions(kv, sv, v, pv, Nv.data());
    Eigen::RowVectorX row = Eigen::RowVectorX::Zero(nu + 1, nv + 1);
    // Actually: kron(Nu, Nv) at the appropriate global indices.
    Eigen::RowVectorX rowflat = Eigen::RowVectorX::Zero((nu + 1) * (nv + 1));
    for (std::size_t i = 0; i <= pu; ++i) {
        const std::size_t gi = su - pu + i;
        for (std::size_t j = 0; j <= pv; ++j) {
            const std::size_t gj = sv - pv + j;
            const Real val = Nu[i] * Nv[j];
            rowflat(gi * (nv + 1) + gj) = val;
        }
    }
    return rowflat;
}

}  // namespace

Surface FitSurfaceFromConstraints(
    const std::vector<DataConstraint>& data,
    const std::vector<HardPointConstraint>& hard_points,
    const BoundaryConstraint* boundary,
    const FitOptions& options) {
    // ---- 1. Default parameters ----------------------------------------
    FitOptions opts = options;
    if (opts.pu < 2) opts.pu = 3;
    if (opts.pv < 2) opts.pv = 3;
    if (opts.n_ctrl_u == 0) {
        opts.n_ctrl_u = std::max<std::size_t>(opts.pu + 1, data.size() / 4);
    }
    if (opts.n_ctrl_v == 0) {
        opts.n_ctrl_v = std::max<std::size_t>(opts.pv + 1,
                                               (data.empty() ? 8 : data.size() / 4));
    }
    if (opts.n_ctrl_u < opts.pu + 1 || opts.n_ctrl_v < opts.pv + 1) {
        throw std::invalid_argument(
            "FitSurfaceFromConstraints: control point counts must be >= degree+1");
    }
    const std::size_t nu = opts.n_ctrl_u - 1;
    const std::size_t nv = opts.n_ctrl_v - 1;

    // ---- 2. Knot vectors ----------------------------------------------
    KnotVector ku = KnotVector::UniformClamped(opts.n_ctrl_u, opts.pu);
    KnotVector kv = KnotVector::UniformClamped(opts.n_ctrl_v, opts.pv);

    // ---- 3. Build constraint list -------------------------------------
    std::vector<ConstraintRow> rows;
    rows.reserve(data.size() + hard_points.size() + 64);

    for (const auto& d : data) {
        rows.push_back({d.u, d.v, d.p, d.weight});
    }
    for (const auto& h : hard_points) {
        rows.push_back({h.u, h.v, h.p, h.lambda});
    }
    if (boundary) {
        // Four edges: u=0, u=1, v=0, v=1.
        // We expect boundary->curve_u (along u, parameterised in [0,1])
        // and boundary->curve_v (along v, parameterised in [0,1]).
        const std::size_t n = boundary->n_samples;
        for (std::size_t k = 0; k < n; ++k) {
            const Real t = (n == 1) ? Real(0.5)
                                    : static_cast<Real>(k) / static_cast<Real>(n - 1);
            // u=0 boundary (v varies along the v-axis curve)
            {
                Vec3 p = boundary->curve_v.PointAt(t);
                rows.push_back({Real(0), t, p, boundary->lambda});
            }
            // u=1 boundary
            {
                Vec3 p = boundary->curve_v.PointAt(t);
                rows.push_back({Real(1), t, p, boundary->lambda});
            }
            // v=0 boundary
            {
                Vec3 p = boundary->curve_u.PointAt(t);
                rows.push_back({t, Real(0), p, boundary->lambda});
            }
            // v=1 boundary
            {
                Vec3 p = boundary->curve_u.PointAt(t);
                rows.push_back({t, Real(1), p, boundary->lambda});
            }
        }
    }
    if (rows.empty()) {
        throw std::invalid_argument(
            "FitSurfaceFromConstraints: no constraints provided");
    }

    // ---- 4. Build the design matrix N (rows x (n_ctrl_u * n_ctrl_v)) -
    const std::size_t n_unknowns = (nu + 1) * (nv + 1);
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Nmat(rows.size(), n_unknowns);
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Ymat(rows.size(), 3);
    Eigen::Matrix<Real, Eigen::Dynamic, 1> Wdiag(rows.size());
    std::vector<Real> Nu(opts.pu + 1), Nv(opts.pv + 1);
    for (std::size_t r = 0; r < rows.size(); ++r) {
        Eigen::RowVectorX row = BuildBasisRow(ku, kv, opts.pu, opts.pv, nu, nv,
                                              rows[r].u, rows[r].v, Nu, Nv);
        Nmat.row(r) = row;
        Ymat.row(r) = rows[r].p.transpose();
        Wdiag(r) = rows[r].w;
    }

    // ---- 5. Solve weighted least squares -----------------------------
    // We minimise sum_r w_r * ||N_r x - y_r||^2 + ridge * ||x||^2.
    // This is equivalent to solving
    //     (A^T W A + ridge I) x = A^T W y
    // where W is diagonal.
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Wsqrt =
        Wdiag.array().sqrt().matrix().asDiagonal();
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> A = Wsqrt * Nmat;
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> Y = Wsqrt * Ymat;
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> AtA =
        A.transpose() * A + opts.ridge * Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic>::Identity(n_unknowns, n_unknowns);
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> AtY = A.transpose() * Y;
    Eigen::Matrix<Real, Eigen::Dynamic, Eigen::Dynamic> X =
        AtA.ldlt().solve(AtY);

    // ---- 6. Reshape into (n_ctrl_u, n_ctrl_v) control grid ----------
    std::vector<std::vector<ControlPoint4>> grid(
        opts.n_ctrl_u, std::vector<ControlPoint4>(opts.n_ctrl_v));
    for (std::size_t i = 0; i < opts.n_ctrl_u; ++i) {
        for (std::size_t j = 0; j < opts.n_ctrl_v; ++j) {
            Vec3 p;
            p << X(i * (nv + 1) + j, 0),
                 X(i * (nv + 1) + j, 1),
                 X(i * (nv + 1) + j, 2);
            grid[i][j] = ControlPoint4(p);
        }
    }
    return Surface(opts.pu, opts.pv, std::move(grid), std::move(ku), std::move(kv));
}

}  // namespace nurbs_filler