// tests/test_surface.cpp
#include <nurbs_filler/surface.h>

#include <gtest/gtest.h>

#include <cmath>
#include <vector>

using namespace nurbs_filler;

TEST(Surface, GlobalInterpolationGridPassesThrough) {
    // 5x5 grid on a saddle surface z = x*y.
    std::vector<std::vector<Vec3>> grid(5, std::vector<Vec3>(5));
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            const Real x = static_cast<Real>(i) / 4.0;
            const Real y = static_cast<Real>(j) / 4.0;
            grid[i][j] = Vec3(x, y, x * y);
        }
    }
    Surface s = Surface::GlobalInterpolationGrid(3, 3, grid);
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            const Real u = static_cast<Real>(i) / 4.0;
            const Real v = static_cast<Real>(j) / 4.0;
            Vec3 got = s.PointAt(u, v);
            EXPECT_NEAR(got.x(), grid[i][j].x(), 1e-7);
            EXPECT_NEAR(got.y(), grid[i][j].y(), 1e-7);
            EXPECT_NEAR(got.z(), grid[i][j].z(), 1e-7);
        }
    }
}

TEST(Surface, PointAtMatchesAnalytical) {
    // Build a flat surface: S(u, v) = (u, v, 0). Use a simple 2x2 control
    // grid with degree 1.
    std::vector<std::vector<ControlPoint4>> grid(2, std::vector<ControlPoint4>(2));
    grid[0][0] = ControlPoint4(Vec3(0, 0, 0));
    grid[0][1] = ControlPoint4(Vec3(0, 1, 0));
    grid[1][0] = ControlPoint4(Vec3(1, 0, 0));
    grid[1][1] = ControlPoint4(Vec3(1, 1, 0));
    Surface s(1, 1, std::move(grid),
              KnotVector::UniformClamped(2, 1),
              KnotVector::UniformClamped(2, 1));
    for (Real u : {0.0, 0.3, 0.5, 0.7, 1.0})
        for (Real v : {0.0, 0.3, 0.5, 0.7, 1.0}) {
            Vec3 got = s.PointAt(u, v);
            EXPECT_NEAR(got.x(), u, 1e-9);
            EXPECT_NEAR(got.y(), v, 1e-9);
            EXPECT_NEAR(got.z(), 0.0, 1e-9);
        }
}

TEST(Surface, TriangulateProducesQuads) {
    Surface s = Surface::GlobalInterpolationGrid(
        3, 3, std::vector<std::vector<Vec3>>{
            {Vec3(0,0,0), Vec3(0,1,0), Vec3(0,2,0)},
            {Vec3(1,0,0), Vec3(1,1,1), Vec3(1,2,0)},
            {Vec3(2,0,0), Vec3(2,1,0), Vec3(2,2,0)}});
    std::vector<Vec3> pos;
    std::vector<std::array<std::size_t, 3>> tris;
    s.Triangulate(5, 5, &pos, &tris);
    EXPECT_EQ(pos.size(), 25u);
    EXPECT_EQ(tris.size(), 2 * 4 * 4);   // 4 quads per direction, 2 tris each
}