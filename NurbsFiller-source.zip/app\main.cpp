// app/main.cpp
//
// nurbsfiller — CLI tool for fitting a NURBS surface to a CSV point cloud.
//
// Input CSV format (one point per line):
//     u,v,x,y,z[,weight]
// where weight is optional and defaults to 1.
//
// Example:
//     0.1,0.2,1.0,2.0,3.0,1.0
//
// Output:
//   * Default: writes a triangulated mesh of the fitted surface as
//     Wavefront OBJ (the path given by --out, default surface.obj).
//   * --emit-controlpoints : also writes the (nu x nv) control grid to
//     a sibling CSV named <out>.ctrl.csv.
//
// Usage:
//     nurbsfiller --in points.csv --degree 3 --nu 12 --nv 24 --out surf.obj

#include <nurbs_filler/curve.h>
#include <nurbs_filler/fitting.h>
#include <nurbs_filler/surface.h>
#include <nurbs_filler/types.h>

#include <Eigen/Dense>

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

struct CliOptions {
    std::string input_csv;
    std::string out_path = "surface.obj";
    std::size_t pu = 3;
    std::size_t pv = 3;
    std::size_t n_ctrl_u = 0;
    std::size_t n_ctrl_v = 0;
    std::size_t sample_u = 32;
    std::size_t sample_v = 32;
    bool emit_controlpoints = false;
};

void PrintUsage() {
    std::cout <<
        "Usage: nurbsfiller --in points.csv [options]\n"
        "  --in <path>          CSV with rows u,v,x,y,z[,weight]\n"
        "  --out <path>         output OBJ file (default surface.obj)\n"
        "  --pu <int>           degree in u (default 3)\n"
        "  --pv <int>           degree in v (default 3)\n"
        "  --nu <int>           number of control points in u (default auto)\n"
        "  --nv <int>           number of control points in v (default auto)\n"
        "  --su <int>           sampling resolution in u (default 32)\n"
        "  --sv <int>           sampling resolution in v (default 32)\n"
        "  --emit-controlpoints write control grid alongside OBJ\n"
        "  --help               show this help\n";
}

bool ParseUInt(const std::string& s, std::size_t* out) {
    try {
        std::size_t v = std::stoul(s);
        *out = v;
        return true;
    } catch (...) { return false; }
}

bool ParseOptions(int argc, char** argv, CliOptions* opts) {
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--help" || a == "-h") { PrintUsage(); std::exit(0); }
        else if (a == "--in" && i + 1 < argc) opts->input_csv = argv[++i];
        else if (a == "--out" && i + 1 < argc) opts->out_path = argv[++i];
        else if (a == "--pu" && i + 1 < argc) {
            if (!ParseUInt(argv[++i], &opts->pu)) return false;
        } else if (a == "--pv" && i + 1 < argc) {
            if (!ParseUInt(argv[++i], &opts->pv)) return false;
        } else if (a == "--nu" && i + 1 < argc) {
            if (!ParseUInt(argv[++i], &opts->n_ctrl_u)) return false;
        } else if (a == "--nv" && i + 1 < argc) {
            if (!ParseUInt(argv[++i], &opts->n_ctrl_v)) return false;
        } else if (a == "--su" && i + 1 < argc) {
            if (!ParseUInt(argv[++i], &opts->sample_u)) return false;
        } else if (a == "--sv" && i + 1 < argc) {
            if (!ParseUInt(argv[++i], &opts->sample_v)) return false;
        } else if (a == "--emit-controlpoints") {
            opts->emit_controlpoints = true;
        } else {
            std::cerr << "Unknown / malformed option: " << a << "\n";
            return false;
        }
    }
    return !opts->input_csv.empty();
}

std::vector<nurbs_filler::DataConstraint> ReadCsv(const std::string& path) {
    std::ifstream f(path);
    if (!f) throw std::runtime_error("Cannot open " + path);
    std::vector<nurbs_filler::DataConstraint> out;
    std::string line;
    int line_no = 0;
    while (std::getline(f, line)) {
        ++line_no;
        // Skip blanks and comments
        if (line.empty()) continue;
        if (line[0] == '#' || line[0] == '%') continue;
        std::istringstream iss(line);
        std::string tok;
        std::vector<double> vals;
        while (std::getline(iss, tok, ',')) {
            try {
                vals.push_back(std::stod(tok));
            } catch (...) {
                std::cerr << "warn: line " << line_no
                          << ": cannot parse '" << tok << "'\n";
            }
        }
        if (vals.size() < 5) {
            std::cerr << "warn: line " << line_no
                      << ": expected at least u,v,x,y,z, skipping\n";
            continue;
        }
        nurbs_filler::DataConstraint d;
        d.u = vals[0];
        d.v = vals[1];
        d.p = nurbs_filler::Vec3(vals[2], vals[3], vals[4]);
        d.weight = (vals.size() >= 6) ? vals[5] : 1.0;
        out.push_back(d);
    }
    return out;
}

void WriteObj(const std::string& path,
              const std::vector<nurbs_filler::Vec3>& positions,
              const std::vector<std::array<std::size_t, 3>>& tris) {
    std::ofstream f(path);
    if (!f) throw std::runtime_error("Cannot open " + path + " for writing");
    f << "# NurbsFiller output\n";
    for (const auto& p : positions) {
        f << "v " << p.x() << ' ' << p.y() << ' ' << p.z() << '\n';
    }
    for (const auto& t : tris) {
        f << "f " << (t[0] + 1) << ' ' << (t[1] + 1) << ' ' << (t[2] + 1) << '\n';
    }
}

void WriteCtrlCsv(const std::string& path, const nurbs_filler::Surface& surf) {
    std::ofstream f(path);
    if (!f) throw std::runtime_error("Cannot open " + path + " for writing");
    f << "# Control grid: i,j,x,y,z,w\n";
    for (std::size_t i = 0; i < surf.NumControlPointsU(); ++i) {
        for (std::size_t j = 0; j < surf.NumControlPointsV(); ++j) {
            const auto& cp = surf.ControlGrid()[i][j];
            f << i << ',' << j << ',' << cp.p.x() << ',' << cp.p.y() << ','
              << cp.p.z() << ',' << cp.w << '\n';
        }
    }
}

}  // namespace

int main(int argc, char** argv) {
    CliOptions opts;
    if (!ParseOptions(argc, argv, &opts)) {
        PrintUsage();
        return 1;
    }

    std::vector<nurbs_filler::DataConstraint> data;
    try {
        data = ReadCsv(opts.input_csv);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 2;
    }
    if (data.empty()) {
        std::cerr << "Error: no valid data points in " << opts.input_csv << "\n";
        return 2;
    }
    std::cout << "Loaded " << data.size() << " data points from "
              << opts.input_csv << "\n";

    nurbs_filler::FitOptions fit_opts;
    fit_opts.pu = opts.pu;
    fit_opts.pv = opts.pv;
    fit_opts.n_ctrl_u = opts.n_ctrl_u;
    fit_opts.n_ctrl_v = opts.n_ctrl_v;
    try {
        auto surface = nurbs_filler::FitSurfaceFromConstraints(
            data, /*hard_points=*/{}, /*boundary=*/nullptr, fit_opts);
        std::cout << "Fitted surface: " << surface.NumControlPointsU()
                  << "x" << surface.NumControlPointsV() << " control points\n";

        std::vector<nurbs_filler::Vec3> positions;
        std::vector<std::array<std::size_t, 3>> triangles;
        surface.Triangulate(opts.sample_u, opts.sample_v,
                             &positions, &triangles);
        WriteObj(opts.out_path, positions, triangles);
        std::cout << "Wrote OBJ: " << opts.out_path << " ("
                  << positions.size() << " verts, "
                  << triangles.size() << " tris)\n";

        if (opts.emit_controlpoints) {
            std::string ctrl_path = opts.out_path + ".ctrl.csv";
            WriteCtrlCsv(ctrl_path, surface);
            std::cout << "Wrote control grid: " << ctrl_path << "\n";
        }
    } catch (const std::exception& e) {
        std::cerr << "Fitting failed: " << e.what() << "\n";
        return 3;
    }
    return 0;
}