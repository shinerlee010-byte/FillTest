// src/basis.cpp
//
// B-spline basis functions and their derivatives.
//
// We implement:
//   1. Algorithm A2.2 (Piegl & Tiller) for the p+1 non-zero basis
//      functions at u.
//   2. The recursive derivative identity
//
//        N^{(k)}_{i,j}(u) = j * ( N^{(k-1)}_{i,   j-1}(u) / (U[i+j]   - U[i])
//                            -  N^{(k-1)}_{i+1, j-1}(u) / (U[i+j+1] - U[i+1]) )
//
//      When a knot difference is zero, the corresponding quotient is taken
//      as 0 (Cox-de Boor convention).
//
// We compute a full (k_max+1) x (p+1) x (p+1) tensor `all` whose entry
// `all[j * stride_k + k * local + i] = N^{(k)}_{i, j}(u)`. We extract the
// slice j = p as the result.
//
// References:
//   Piegl L., Tiller W. "The NURBS Book", 2nd ed., Springer 1997,
//   Chapter 2.

#include <nurbs_filler/basis.h>

#include <algorithm>
#include <cstring>
#include <stdexcept>
#include <vector>

namespace nurbs_filler {

namespace {

// Fill ndu[j * (p+1) + i] = N^{(0)}_{i, j}(u) for j in [0..p], i in [0..j].
// Algorithm A2.2 (Piegl & Tiller), lower-triangular scheme.
void FillNdu(const Real* U, std::size_t span, Real u, std::size_t p,
             Real* ndu) {
    ndu[0 * (p + 1) + 0] = Real(1);
    std::vector<Real> left(p + 1);
    std::vector<Real> right(p + 1);
    for (std::size_t j = 1; j <= p; ++j) {
        left[j]  = u - U[span + 1 - j];
        right[j] = U[span + j] - u;
        Real saved = Real(0);
        for (std::size_t r = 0; r < j; ++r) {
            const Real denom = right[r + 1] + left[j - r];
            const Real temp = (denom != Real(0))
                                  ? ndu[(j - 1) * (p + 1) + r] / denom
                                  : Real(0);
            ndu[j * (p + 1) + r] = saved + right[r + 1] * temp;
            saved = left[j - r] * temp;
        }
        ndu[j * (p + 1) + j] = saved;
    }
}

// Compute all N^{(k)}_{i, p}(u) for k in [0..k_max], i in [span-p..span].
// Output layout: ders[k * (p+1) + i_local] where i_local = i - (span - p).
void LocalDerivatives(const Real* U, std::size_t span, Real u,
                      std::size_t p, int k_max, Real* ders) {
    const std::size_t local = p + 1;
    const std::size_t stride_k = (static_cast<std::size_t>(k_max) + 1) * local;

    // Tensor `all`:
    //   all[(j) * stride_k + (k) * local + (i)]
    //     = N^{(k)}_{i, j}(u), j in [0..p], k in [0..k_max], i in [0..j].
    std::vector<Real> all((p + 1) * stride_k, Real(0));

    // ---- 0th derivatives via A2.2 ----
    std::vector<Real> ndu((p + 1) * (p + 1), Real(0));
    FillNdu(U, span, u, p, ndu.data());
    for (std::size_t j = 0; j <= p; ++j) {
        for (std::size_t i = 0; i <= j; ++i) {
            all[j * stride_k + 0 * local + i] = ndu[j * (p + 1) + i];
        }
    }

    // ---- Higher derivatives via recursive identity ----
    for (int k = 1; k <= k_max; ++k) {
        for (std::size_t j = static_cast<std::size_t>(k); j <= p; ++j) {
            for (std::size_t i = 0;
                 i + static_cast<std::size_t>(k) <= j; ++i) {
                const std::size_t gi = span - p + i;
                const Real a = U[gi + j]     - U[gi];
                const Real b = U[gi + j + 1] - U[gi + 1];
                Real left_term  = Real(0);
                Real right_term = Real(0);
                if (a != Real(0)) {
                    left_term = all[(j - 1) * stride_k +
                                    static_cast<std::size_t>(k - 1) * local + i] /
                                a;
                }
                if (b != Real(0)) {
                    right_term = all[(j - 1) * stride_k +
                                     static_cast<std::size_t>(k - 1) * local +
                                     (i + 1)] /
                                 b;
                }
                all[j * stride_k + static_cast<std::size_t>(k) * local + i] =
                    static_cast<Real>(j) * (left_term - right_term);
            }
        }
    }

    // ---- Extract degree p slice into `ders` ----
    for (int k = 0; k <= k_max; ++k) {
        for (std::size_t i = 0;
             i + static_cast<std::size_t>(k) <= p; ++i) {
            ders[static_cast<std::size_t>(k) * local + i] =
                all[p * stride_k + static_cast<std::size_t>(k) * local + i];
        }
    }
}

}  // namespace

void BasisFunctions(const KnotVector& knot, std::size_t span, Real u,
                    std::size_t p, Real* N_out) {
    N_out[0] = Real(1);
    std::vector<Real> left(p + 1);
    std::vector<Real> right(p + 1);
    const auto& U = knot.Values();
    for (std::size_t j = 1; j <= p; ++j) {
        left[j]  = u - U[span + 1 - j];
        right[j] = U[span + j] - u;
        Real saved = Real(0);
        for (std::size_t r = 0; r < j; ++r) {
            const Real denom = right[r + 1] + left[j - r];
            const Real temp = (denom != Real(0)) ? N_out[r] / denom : Real(0);
            N_out[r] = saved + right[r + 1] * temp;
            saved = left[j - r] * temp;
        }
        N_out[j] = saved;
    }
}

void AllBasisFunctions(const KnotVector& knot, std::size_t n, std::size_t p,
                       Real u, Real* N_out) {
    std::memset(N_out, 0, (n + 1) * sizeof(Real));
    const std::size_t span = knot.FindSpan(n, p, u);
    BasisFunctions(knot, span, u, p, N_out + (span - p));
}

void AllBasisFunctionDerivatives(const KnotVector& knot, std::size_t n,
                                 std::size_t p, Real u, int k,
                                 Real* dN_out) {
    if (k > static_cast<int>(p)) {
        throw std::invalid_argument(
            "AllBasisFunctionDerivatives: k must be <= p");
    }
    std::memset(dN_out, 0, (k + 1) * (n + 1) * sizeof(Real));
    const std::size_t span = knot.FindSpan(n, p, u);
    LocalDerivatives(knot.Values().data(), span, u, p, k,
                     dN_out + (span - p));
}

void BasisFunctionDerivativesAll(const KnotVector& knot, std::size_t n,
                                 std::size_t p, Real u, int k,
                                 Real* derivs) {
    if (k > static_cast<int>(p)) {
        throw std::invalid_argument(
            "BasisFunctionDerivativesAll: k must be <= p");
    }
    std::memset(derivs, 0, (k + 1) * (n + 1) * sizeof(Real));
    const std::size_t span = knot.FindSpan(n, p, u);
    LocalDerivatives(knot.Values().data(), span, u, p, k,
                     derivs + (span - p));
}

}  // namespace nurbs_filler